package com.users_data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsondbApplicationTests {

	@Test
	void contextLoads() {
	}

}
